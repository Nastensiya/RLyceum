from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///survey.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Модель для результатов опроса
class SurveyResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50))
    grade = db.Column(db.String(20))
    school = db.Column(db.String(100))
    favorite_subject = db.Column(db.String(50))
    grades = db.Column(db.String(20))

# Создаем базу данных при первом запуске
if not os.path.exists('instance/survey.db'):
    with app.app_context():
        db.create_all()

@app.route('/', methods=['GET', 'POST'])
def survey():
    if request.method == 'POST':
        # Получаем данные из формы
        name = request.form['name']
        grade = request.form['grade']
        school = request.form['school']
        favorite_subject = request.form['favorite_subject']
        grades = request.form['grades']
        
        # Сохраняем в базу данных
        new_result = SurveyResult(
            name=name,
            grade=grade,
            school=school,
            favorite_subject=favorite_subject,
            grades=grades
        )
        db.session.add(new_result)
        db.session.commit()
        
        return redirect(url_for('thank_you'))
    
    return render_template('survey.html')

@app.route('/thank-you')
def thank_you():
    return render_template('thank_you.html')

if __name__ == '__main__':
    app.run(debug=  True)
